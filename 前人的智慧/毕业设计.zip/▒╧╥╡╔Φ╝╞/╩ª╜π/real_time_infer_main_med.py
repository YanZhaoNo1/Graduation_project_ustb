import struct

import cv2
import threading
import copy
import socket

from matplotlib import pyplot as plt
from mediapipe.tasks.python.components.containers import Landmark
from mediapipe.tasks.python.vision import PoseLandmarkerResult
from ultralytics import YOLO
from mmaction.apis import init_recognizer, inference_recognizer
from queue import Queue
import numpy as np
import subprocess
import queue

import cv2
import mediapipe as mp
import numpy as np
from mediapipe.framework.formats import landmark_pb2
from mediapipe.python import solutions
from mediapipe.tasks import python
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import tensorflow as tf

class InterferSystem:
    def __init__(self):

        # 初始化目标检测模型
        self.yolo_model = YOLO(model="E:/wbb/HumanAction_project/YOLO/ultralytics/runs/detect/train22/weights/best.pt")

        # 初始化动作识别模型
        # 放弃mmpose 改用google的bodypose
        # config_file = 'E:/wbb/HumanAction_project/ActionRecognition/mmaction2/work_dirs/240122TSN/tsn_imagenet-pretrained-r50_8xb32-1x1x3-100e_kinetics400-rgb.py'
        # checkpoint_file = 'E:/wbb/HumanAction_project/ActionRecognition/mmaction2/work_dirs/240122TSN/epoch_200.pth'
        # action_label = 'label_map_007.txt'
        # google的bodypose
        action_model_path = 'pose_landmarker_heavy.task'
        BaseOptions = mp.tasks.BaseOptions
        self.PoseLandmarker = mp.tasks.vision.PoseLandmarker
        PoseLandmarkerOptions = mp.tasks.vision.PoseLandmarkerOptions
        PoseLandmarkerResult = mp.tasks.vision.PoseLandmarkerResult
        VisionRunningMode = mp.tasks.vision.RunningMode

        self.options = PoseLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=action_model_path),
            running_mode=VisionRunningMode.LIVE_STREAM,
            result_callback=self.print_result)


        self.detected_objects_dic_list = []
        # 初始化动作识别结果---字典
        self.action_label_dic = {
            0: 'Endpanel',
            1: 'crate',
            2: 'LRMconnector',
            3: 'SMAcoupler',
            4: 'Printedboard',
            5: 'wire',
            6: 'Stop'
        }
        # 初始化字典----结果打包发送
        self.result_dic = {
            'M1-keep': 0,
            'M1-stop': 1,
            'M2-keep': 2,
            'M2-stop': 3,
            'M3-keep': 4,
            'M3-stop': 5,
            'M4-keep': 6,
            'M4-stop': 7,
            'M5-keep': 8,
            'M5-stop': 9,
            'waring': 10,
            'No Match': 11
        }


        # 创建一个服务器Socket
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 使用想要发送的目标的地址和端口  python 端口为 8888 hololens2端口为 7777
        self.s_add_p = ('192.168.139.177', 7777)   # 如果在本机发送的话IP是127.0.0.1   端口是7000       192.168.172.33

        # self.server_socket.bind(('localhost', 8888))  # 绑定到本地主机的8888端口
        # self.server_socket.listen(1)  # 监听连接请求，最大连接数为1


        # 用于线程间通信的事件
        self.detection_event = threading.Event() # 主线程通知子线程
        self.detection_com_event = threading.Event() # 子线程通知主线程
        self.action_event = threading.Event()
        self.action_com_event = threading.Event() # 子线程通知主线程

        # 共享变量，用于存储目标检测和动作识别结果
        self.detection_result = None
        self.action_result = None
        self.result = None
        # 创建保存帧的列表
        self.frame_list = []
        self.frame_detected_list = []
        self.frame_list_150 = []

        # 保存目标检测的结果
        self.detected_objects_list = []
        self.detected_objects_count_list = []
        self.detected_objects_list_set = []
        self.detected_objects_dic = {}
        self.detected_result = []

        self.detected_objects_list_150 = []

        self.frame_list_action_list = []


        # 队列，用于存储视频帧
        self.frame_dect_queue = Queue()  # 150是队列的最大容量，可以根据实际情况调整
        self.frame_list_queue = Queue()
        self.frame_action_queue = Queue()  # 150是队列的最大容量，可以根据实际情况调整
        self.action_result_queue = Queue()  # 存放动作识别的结果
        self.annotated_frame_queue = Queue()
        self.dectected_result_queue = Queue() # 存放150帧目标检测的结果
        self.action_res_frame_que = Queue()

        # 队列，用于存储推理的结果
        self.send_data_queue = Queue(maxsize=500)

        # 启动视频读取线程
        self.read_video_t = threading.Thread(target=self.read_video_thread)
        self.read_video_t.start()

        # 启动目标检测线程
        self.detection_t = threading.Thread(target=self.detection_thread)
        self.detection_t.start()

        # 启动动作识别线程
        self.action_t = threading.Thread(target=self.action_thread)
        self.action_t.start()

        # 启动结果处理线程
        self.get_result_t = threading.Thread(target=self.get_result_thread)
        self.get_result_t.start()

        # 启动线程-----用于发送数据包
        self.send_data_t = threading.Thread(target=self.send_data_thread)
        self.send_data_t.start()

    def send_data_test(self):
        while True:
            self.server_socket.sendto(struct.pack('H',123), self.s_add_p)

    # 线程函数：用于发送联合推理的结果到客户端
    def send_data_thread(self):
        # self.send_data_test()

        while True:

            # 接受客户端连接
            print("已进入发送线程：")
            # 通过队列获取数据包  获取到才能发
            # 把结果从队列取出
            data_packet = self.send_data_queue.get()
            # 数据预处理
            # 获取要发送的结果值
            send_data = self.result_dic[data_packet]

            print('获取到的推理结果的值为：' + str(send_data))
            data_bytes = struct.pack('H', send_data)
            self.server_socket.sendto(data_bytes, self.s_add_p)
            # client_socket, client_address = self.server_socket.accept()
            # 关闭连接
            # self.server_socket.close()

    # 函数：用于处理目标检测和动作识别的结果的线程
    def get_result_thread(self):
        # 进入总识别模块
        print('进入结果的总识别模块')
        # 对总体识别结果进行计数
        result_times = 0
        while True:
            # 获取目标检测和动作识别的结果
            print("进入总推理线程")
            action_type = self.action_type_que.get()
            dectected_result_150_curr = self.dectected_result_queue.get()
            # 做判断
            if action_type is not None and dectected_result_150_curr is not None:
                # 根据条件进行判断
                # 当检测到是keep状态时，持续3次触发一次推送指令，之后虽然一直在检测，但是不执行，直到检测到下一个状态
                if action_type == 'Action' and 'board' in dectected_result_150_curr:
                    result = "M1-keep"     # 不推送
                elif action_type == 'Stop' and 'board' in dectected_result_150_curr:
                    result = "M1-stop"
                elif action_type == 'Action' and 'rack' in dectected_result_150_curr and 'pb' not in dectected_result_150_curr and 'sma'not in dectected_result_150_curr and 'prb' not in dectected_result_150_curr:
                    result = "M2-keep"
                elif action_type == 'Stop' and 'rack' in dectected_result_150_curr and 'pb' in dectected_result_150_curr and 'prb' not in dectected_result_150_curr and 'sma' not in dectected_result_150_curr and 'wire' not in dectected_result_150_curr:
                    result = "M2-stop"
                elif action_type == 'SMAcoupler' and 'sma' in dectected_result_150_curr and 'lrm' in dectected_result_150_curr and 'pb' in dectected_result_150_curr:
                    result = "M3-keep"
                elif action_type == 'Stop' and 'sma' in dectected_result_150_curr and 'pb' in dectected_result_150_curr:
                    result = "M3-stop"
                elif action_type == 'Action' and 'rack' in dectected_result_150_curr  and 'pb' in dectected_result_150_curr and 'sma' in dectected_result_150_curr and 'prb' in dectected_result_150_curr:
                    result = "M4-keep"
                elif action_type == 'Stop' and 'rack' in dectected_result_150_curr and 'prb' in dectected_result_150_curr:
                    result = "M4-stop"
                elif action_type == 'wire' and 'wire' in dectected_result_150_curr:
                    result = "M5-keep"
                elif action_type == 'Stop' and 'wire' in dectected_result_150_curr and 'rack' in dectected_result_150_curr:
                    result = "M5-stop"
                elif action_type == 'wrong' in dectected_result_150_curr:
                    result = "warning"
                else:
                    result = "No Match"
            result_times = result_times + 1
            # print('总体识别的结果为：' + result)
            print('第 ' + str(result_times) + " 次总体识别的结果为：" + result)
            self.result = result

            # 将结果放入队列
            self.send_data_queue.put(self.result)


    def detection_thread(self):
        while True:
            # 获取图像 get会阻塞线程
            frame = self.frame_dect_queue.get()
            print('目标检测任务队列的长度为 ' + str(self.frame_dect_queue.qsize()) + ' ')
            # 进行目标检测
            self.detection_result = self.yolo_model.predict([frame], show=True)  # , save=True)
            self.frame_detected_list.append(frame)
            print('目标检测任务进行中：' + '这是第 ' + str(len(self.frame_detected_list)) + '帧图像')
            # Assuming self.detection_resultdetection_result is a list of Results objects
            if self.detection_result and len(self.detection_result) > 0:
                # Accessing the class labels (names) and boxes from the first result
                # result = self.detection_result[0]
                detected_classes = []
                detected_objects_result = []
                for r in self.detection_result:
                    boxes = r.boxes  # Boxes object for bbox outputs
                    masks = r.masks  # Masks object for segment masks outputs
                    probs = r.probs  # Class probabilities for classification outputs
                    class_ids = boxes.cls.cpu().numpy().astype(int)  # 转为int类型数组
                    # num = np.sum(class_ids == 0)  # 对类别为0的检测框数目作一个统计
                    detected_classes.append(class_ids)  # 获取检测到的类别信息
                    # 将类别信息保存到列表中
                    detected_objects_result = [r.names[id] for id in class_ids]

                # 将结果保存到列表中
                self.detected_objects_list.extend(detected_objects_result)  # 保存目标检测的结果
                self.detected_objects_count_list.append(detected_objects_result)
                ############# 总结10帧的检测结果    选择检测结果 ############
                if (len(self.detected_objects_count_list) % 10 == 0):
                    # 获取非重复列表
                    self.detected_objects_list_set = set(self.detected_objects_list)
                    # 遍历非重复列表
                    for item in self.detected_objects_list_set:
                        # 把检测出的物体和出现的次数存入字典
                        self.detected_objects_dic[item] = self.detected_objects_list.count(item)
                        print('在10帧的图像中，结果为 ' + item + '有 ' + str(
                            self.detected_objects_list.count(item)) + '次')
                    # 对字典进行降序排序 从而获得出现次数最多的零组件
                    self.detected_objects_dic_list = sorted(self.detected_objects_dic.items(), key=lambda d: d[1],
                                                       reverse=True)
                    # 获取字典中出现结果最多的两个和元素
                    self.detected_result = [self.detected_objects_dic_list[i][0] for i in
                                            range(0, len(self.detected_objects_dic_list))]

                    time = len(self.detected_objects_count_list) / 10
                    self.dectected_result_queue.put(self.detected_result)

                    print("10帧的目标检测结果完成")

                    # 清空这一次的结果
                    self.detected_objects_list.clear()
                    self.detected_objects_dic.clear()

                # 绘制目标检测结果
                self.annotated_frame_queue.put(self.detection_result[0])

    def run_recognition_demo(self):
        # 替换为你实际的文件路径
        config_path = "configs/recognition/tsn/tsn_r50_video_inference_1x1x3_100e_kinetics400_rgb.py"
        checkpoint_path = "checkpoints/tsn_r50_1x1x3_100e_kinetics400_rgb_20200614-e508be42.pth"
        label_map_path = "tools/data/kinetics/label_map_k400.txt"

        # 构建命令行参数列表
        command = [
            "python",
            "demo/webcam_demo.py",
            config_path,
            checkpoint_path,
            label_map_path,
            "--average-size", "5",
            "--threshold", "0.2",
            "--device", "cpu"
        ]

        # 执行命令
        subprocess.run(command)

    res_que = queue.Queue()
    action_type_que = queue.Queue()
    def print_result(self,result: PoseLandmarkerResult, output_image: mp.Image, timestamp_ms: int):
        print('pose landmarker result: {}'.format(result))
        self.res_que.put(result)

    def con_pose_landmark(self,_pose_landmark):
        pose_landmarks_list = []
        pose_landmarks = _pose_landmark
        for item in pose_landmarks[0]:
            pose_landmark = []
            pose_landmark = self.new_append(pose_landmark,item)
            pose_landmarks_list.append(pose_landmark)
        return pose_landmarks_list

    def new_append(self, _list: list, _item: Landmark):
        '''一个重复的功能 一定要有返回值'''
        _list.append(round(_item.x, 3))
        _list.append(round(_item.y, 3))
        return _list
    def judge_stop(self,_pose_landmark_list):
        pose_name = ""
        '''停止的条件：左右两臂贴住身体，双手自然下垂
           转化为数学公式：左右臂和双肩的连线不超过120度 左右手手腕的高度不能超过手肘 左右手到肩膀的距离不能大于左右手腕到左右手肘的距离 
        '''


        keypoints = np.array(_pose_landmark_list)
        # 计算左臂和水平方向的夹角
        v1 = keypoints[12] - keypoints[11]
        v2 = keypoints[13] - keypoints[11]
        angle_left_arm = self.get_angle(v1, v2)

        # 计算左手手腕和手肘的高度对比
        left_wrist = keypoints[15]
        left_elbox = keypoints[13]
        is_l_e_high = left_wrist[1] > left_elbox[1] # 在图像中越高像素越小 为真的时候stop

        # 左右手到肩膀的距离不能大于左右手腕到左右手肘
        left_wrist = keypoints[15]
        left_elbox = keypoints[13]
        left_shou = keypoints[11]
        dl_ws = np.sqrt((left_wrist[0] - left_shou[0])**2 + (left_wrist[1] - left_shou[1])**2 )
        dl_es = np.sqrt((left_elbox[0] - left_shou[0])**2 + (left_elbox[1] - left_shou[1])**2 )
        is_l_e_near = dl_es < dl_ws  #  为真的时候stop

        # 左手手腕和手肘的连线和肩的夹角不能太小
        v1 = keypoints[12] - keypoints[11]
        v2 = keypoints[15] - keypoints[13]
        angle_l_ws = self.get_angle(v1, v2)
        is_l_angle_big = angle_l_ws > 35

        # 计算右臂与水平方向的夹角
        v1 = keypoints[11] - keypoints[12]
        v2 = keypoints[14] - keypoints[12]
        angle_right_arm = self.get_angle(v1, v2)

        # 计算右手手腕和手肘的高度对比
        rig_wrist = keypoints[16]
        rig_elbox = keypoints[14]
        is_r_e_high = rig_wrist[1] > rig_elbox[1]  # 在图像中越高像素越小 为真的时候stop

        # 左右手到肩膀的距离不能大于左右手腕到左右手肘
        rig_wrist = keypoints[16]
        rig_elbox = keypoints[14]
        rig_shou = keypoints[12]
        dr_ws = np.sqrt((rig_wrist[0] - rig_shou[0]) ** 2 + (rig_wrist[1] - rig_shou[1]) ** 2)
        dr_es = np.sqrt((rig_elbox[0] - rig_shou[0]) ** 2 + (rig_elbox[1] - rig_shou[1]) ** 2)
        is_r_e_near = dr_es < dr_ws  # 为真的时候stop

        # 左手手腕和手肘的连线和肩的夹角不能太小
        v1 = keypoints[11] - keypoints[12]
        v2 = keypoints[16] - keypoints[14]
        angle_r_ws = self.get_angle(v1, v2)
        is_r_angle_big = angle_r_ws > 35

        # 计算左肘的夹角
        v1 = keypoints[11] - keypoints[13]
        v2 = keypoints[15] - keypoints[13]
        angle_left_elow = self.get_angle(v1, v2)
        # 计算右肘的夹角
        v1 = keypoints[12] - keypoints[14]
        v2 = keypoints[16] - keypoints[14]
        angle_right_elow = self.get_angle(v1, v2)

        if angle_left_arm <120 and angle_right_arm < 120 and is_l_e_high and\
                is_l_e_near and is_r_e_high and is_r_e_near and is_r_angle_big and is_l_angle_big:
            str_pose = "Stop"
        else:
            str_pose = "Action"
        return str_pose

    def get_angle(self,v1, v2): # v1 -> v2 顺时针为正 逆时针为负
        angle = np.dot(v1, v2) / (np.sqrt(np.sum(v1 * v1)) * np.sqrt(np.sum(v2 * v2)))
        angle = np.arccos(angle) / 3.14 * 180

        # cross = v2[0] * v1[1] - v2[1] * v1[0]
        # if cross < 0:
        #     angle = - angle
        return angle

    def draw_landmarks_on_image(self,rgb_image, detection_result):
        pose_landmarks_list = detection_result.pose_landmarks
        annotated_image = np.copy(rgb_image)

        # Loop through the detected poses to visualize.
        for idx in range(len(pose_landmarks_list)):
            pose_landmarks = pose_landmarks_list[idx]

            # Draw the pose landmarks.
            pose_landmarks_proto = landmark_pb2.NormalizedLandmarkList()
            pose_landmarks_proto.landmark.extend([
                landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in pose_landmarks
            ])
            solutions.drawing_utils.draw_landmarks(
                annotated_image,
                pose_landmarks_proto,
                solutions.pose.POSE_CONNECTIONS,
                solutions.drawing_styles.get_default_pose_landmarks_style())
        return annotated_image

    def action_thread(self):
        with tf.device('/device:GPU:0'):
            while True:
                # 从队列中获取frame 会阻塞线程
                frame_list_action = []
                print("进入动作识别模块")
                frame = self.frame_list_queue.get()
                print('动作识别任务队列的长度为 ' + str(self.frame_list_queue.qsize()) + ' ')
                self.frame_list_action_list.append(frame)
                print('动作识别任务进行中：' + '这是第 ' + str(len(self.frame_list_action_list)) + ' 段视频')

                frame_color = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_color)

                with self.PoseLandmarker.create_from_options(self.options) as landmarker:
                    # The landmarker is initialized. Use it here.
                    landmarker.detect_async(mp_image, 1)
                    cur_res = self.res_que.get()
                    # 在这里对stop进行判断 首先获取关键点列表
                    if len(cur_res.pose_landmarks) == 0:
                        action_type = "None"
                        self.action_type_que.put(action_type)
                        print("动作识别的结果为{}".format(action_type))
                        continue
                    pose_landmarks_list = self.con_pose_landmark(cur_res.pose_landmarks)
                    action_type = self.judge_stop(pose_landmarks_list)
                    print("动作识别的结果为{}".format(action_type))
                    self.action_type_que.put(action_type)
                    lm_img = self.draw_landmarks_on_image(frame, cur_res)
                    ## 在左上角绘制动作识别的结果
                    cv2.putText(lm_img, "The action result is " + action_type, (20, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 1.2,
                                (0, 255, 0), 2)
                    cv2.imshow("action",lm_img)
                    if cv2.waitKey(1) == 27:
                        break


    def read_video_thread(self):
        # 视频文件路径
        # video_path = 'rackassembly.mp4'

        # 摄像头编号
        camera_no = 0
        cap = cv2.VideoCapture(camera_no)
        cap.set(cv2.CAP_PROP_FPS, 10);
        fps = 10
        frame_num = 0
        # 提取帧
        # cap = cv2.VideoCapture(video_path)
        while cap.isOpened():

            res, frame = cap.read()

            if res:
                # 用于目标检测的队列
                self.frame_dect_queue.put(frame)
                # 用于动作识别的队列 1帧 为一组
                frame_num = frame_num + 1
                if frame_num == 10:
                    self.frame_list_queue.put(frame)
                    frame_num = 0

        cap.release()

    def write_video_frames(self, frames, video_path):
        # 定义视频对象输出
        fps = 30
        fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
        height, width, _ = frames[0].shape
        out = cv2.VideoWriter(video_path, fourcc, fps, (width, height))

        for frame in frames:
            out.write(frame)

        out.release()
        return out

    def display_detection_results(self):
        # # 创建一个名为 "YOLOV8" 的窗口
        # cv2.namedWindow("YOLOV8", cv2.WINDOW_NORMAL)
        while True:
            # 等待目标检测线程完成 绘制目标检测结果
            start_time = cv2.getTickCount()
            detection_result_main = self.annotated_frame_queue.get()
            plt.ioff()
            annotated_frame_main = detection_result_main.plot() # 把检测结果的图像改为 narray格式
####
            # 这里假设动作识别结果保存在self.action_result中
            if self.action_result is not None:
                print("绘图阶段的动作识别结果" + self.action_result)
                cv2.putText(annotated_frame_main,"The action result is " + self.action_result, (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0),2)

            # 在YOLOv8结果上绘制联合推理结果
            # # 这里假设联合推理结果保存在self.result中
            if self.result is not None:
                cv2.putText(annotated_frame_main, "The inference result is " + self.result, (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            (0, 255, 0), 2)
######
            # 显示绘制结果
            end_time = cv2.getTickCount()
            total_time = (end_time - start_time) / cv2.getTickFrequency()
            fps = round(1/total_time, 2)
            fps_text = fps_text = f"FPS:{fps}"
            cv2.putText(annotated_frame_main, fps_text, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.imshow(winname="YOLOV8", mat=annotated_frame_main)

            # action_res_frame =  self.action_res_frame_que.get()
            # print("动作识别结果的帧队列长度为{}".format(self.action_res_frame_que.qsize()))
            # cv2.imshow(winname="action", mat=action_res_frame)
            # 按ESC退出
            if cv2.waitKey(1) == 27:
                break

        # 释放链接
        # 视频处理结束，放入 None 通知线程结束
        for _ in range(2):
            self.frame_dect_queue.put(None)

        # 等待线程结束
        self.detection_t.join()
        self.action_t.join()
        self.read_video_t.join()
        self.get_result_t.join()

        # 销毁所有窗口
        cv2.destroyAllWindows()

if __name__ == "__main__":
    Interfer_system = InterferSystem()
    Interfer_system.display_detection_results()
