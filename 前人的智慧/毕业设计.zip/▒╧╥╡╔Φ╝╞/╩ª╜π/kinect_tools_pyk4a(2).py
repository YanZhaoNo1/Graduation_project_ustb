import os
import numpy as np
import cv2
from datetime import datetime
from pyk4a import PyK4A, Config, PyK4APlayback, CalibrationType
from pyk4a import ColorResolution, FPS, DepthMode, ImageFormat
from ultralytics import YOLO
from langchain_core.tools import tool


@tool
def get_kinect_images() -> str:
    k4a = PyK4A(
        Config(
            color_resolution=ColorResolution.RES_1080P,
            depth_mode=DepthMode.NFOV_UNBINNED,
            synchronized_images_only=True,
            color_format=ImageFormat.COLOR_BGRA32
        )
    )
    # 启动相机
    k4a.start()
    # 捕捉一帧数据
    capture = k4a.get_capture()
    # 获取 RGB 图像和 深度 图像
    color_image = capture.color
    depth_image = capture.transformed_depth

    # 保存 RGB 图像和 深度 图像
    if (color_image is not None) and (depth_image is not None):
        time_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        cv2.imwrite(
            os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'color_images/',
                         'color_' + time_str + '.png'), color_image)
        cv2.imwrite(
            os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'depth_images/',
                         'depth_' + time_str + '.png'), depth_image)
        # 停止相机和关闭设备
        k4a.stop()
        # 生成回复
        res = "图像已经采集完成\nRBG图像保存保存地址为：" + os.path.join(
            'E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'color_images/',
            'color_' + time_str + '.png') + "\n深度图像保存地址为：" + os.path.join(
            'E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'depth_images/',
            'depth_' + time_str + '.png')
        return res
    # 停止相机和关闭设备
    k4a.stop()
    return "图像采集失败，请重新调用该方法采集图像"


@tool
def object_detection_by_yolo(rgb_image: str) -> str:
    model = YOLO('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\models\\most\\best.pt')
    # 读取待检测图像
    image = cv2.imread(rgb_image)
    # 执行目标检测
    results = model(image)

    # 初始化一个字典存储检测结果
    detections = {}

    # 解析检测结果
    for result in results:
        for box in result.boxes:
            # 获取边界框坐标
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            # 计算中心点坐标
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2

            # 获取检测类别名称
            class_name = result.names[box.cls[0].item()]

            # 将中心点坐标添加到字典
            if class_name not in detections:
                detections[class_name] = []
            detections[class_name].append([center_x, center_y])

    # 绘制检测框及中心点
    annotated_image = results[0].plot()
    for class_name, centers in detections.items():
        for center in centers:
            center_x, center_y = center
            cv2.circle(annotated_image, (center_x, center_y), 5, (0, 255, 0), -1)

    # 保存检测结果图像
    res_path = rgb_image.replace("color", "detected")
    print(res_path)
    cv2.imwrite(res_path, annotated_image)

    # 生成回复
    res = "目标检测已完成，各检测结果在图像中的像素坐标如下：\n"
    for cls, pixel_coordinates in detections.items():
        res += "\n" + cls + "的像素坐标分别为："
        for i in range(len(pixel_coordinates)):
            x = pixel_coordinates[i][0]
            y = pixel_coordinates[i][1]
            res += " " + f"({x}, {y})"
    return res


@tool
def get_object_depth(cls: str, pixel_coordinates: list, image_path: str) -> str:
    depth_image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    # 获取目标深度
    res = "RGB图像上:"
    for i in range(len(pixel_coordinates)):
        x = pixel_coordinates[i][0]
        y = pixel_coordinates[i][1]
        depth_value = depth_image[y, x]
        pixel_coordinates[i] = tuple([x, y, depth_value])
        res += "\n" + f"({x}, {y})点{cls}的深度值: {depth_value} mm"
    return res


@tool
def trans_pixel2camera(cls: str, pixel_coordinates: list) -> str:
    k4a = PyK4A(
        Config(
            color_resolution=ColorResolution.RES_1080P,
            depth_mode=DepthMode.NFOV_UNBINNED,
            synchronized_images_only=True,
            color_format=ImageFormat.COLOR_BGRA32
        )
    )

    # 启动相机
    k4a.start()
    calibration = k4a.calibration
    res = "RGB图像上:"
    for i in range(len(pixel_coordinates)):
        x = pixel_coordinates[i][0]
        y = pixel_coordinates[i][1]
        depth = pixel_coordinates[i][2]
        if depth != 0:
            camera_point = calibration.convert_2d_to_3d(tuple([float(x), float(y)]), depth=float(depth), source_camera=CalibrationType.COLOR)
            res += "\n" + f"({x}, {y})点{cls}在相机坐标系下的坐标为: {camera_point}"
        else:
            # camera_point = tuple([0.0, 0.0, 0.0])
            res += "\n" + f"({x}, {y})点{cls}在相机坐标系下的深度无法获取，可能原因：物体中心颜色为黑色，无法获取深度。出现这种情况后，后续不要再进行任何动作了，立刻返回Final Answer告诉用户深度值无法获取，可能因为物体中心为黑色"
    # k4a.close()
    return res


@tool
def trans_pixel2camera(detections: dict) -> dict:
    k4a = PyK4A(
        Config(
            color_resolution=ColorResolution.RES_1080P,
            depth_mode=DepthMode.NFOV_UNBINNED,
            synchronized_images_only=True,
            color_format=ImageFormat.COLOR_BGRA32
        )
    )

    # 启动相机
    k4a.start()

    calibration = k4a.calibration

    camera_detections = {}
    for cls, pixel_coordinates in detections.items():
        camera_points = []
        for i in range(len(pixel_coordinates)):
            x = pixel_coordinates[i][0]
            y = pixel_coordinates[i][1]
            depth = pixel_coordinates[i][2]
            if depth != 0:
                camera_point = calibration.convert_2d_to_3d(tuple([float(x), float(y)]), depth=float(depth), source_camera=CalibrationType.COLOR)
            else:
                camera_point = tuple([0.0, 0.0, 0.0])
            camera_points.append(camera_point)
            print(f"RGB图像上({x}, {y})点{cls}的坐标为: {camera_point}")
        camera_detections[cls] = camera_points
    print(camera_detections)

    # 停止相机和关闭设备
    k4a.stop()

    return camera_detections


# @tool
# def get_depth_at_rgb_point() -> dict:
     # 初始化 Azure Kinect 相机
#     k4a = PyK4A(
#         Config(
#             color_resolution=ColorResolution.RES_1080P,
#             depth_mode=DepthMode.NFOV_UNBINNED,
#             synchronized_images_only=True,
#             color_format=ImageFormat.COLOR_BGRA32
#         )
#     )
#
#     # 启动相机
#     k4a.start()
#
#     # 捕捉一帧数据
#     capture = k4a.get_capture()
#
#     # 获取 RGB 图像和 深度 图像
#     color_image = capture.color
#     depth_image = capture.transformed_depth
#
#     # 保存 RGB 图像和 深度 图像
#     time_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
#     cv2.imwrite(os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'color_images/', 'color_' + time_str + '.png'), color_image)
#     cv2.imwrite(os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'depth_images/', 'depth_' + time_str + '.png'), depth_image)
#
#     # 停止相机和关闭设备
#     k4a.stop()
#
#     # 调用目标检测模型
#     detections = detect_image_use_yolov8(time_str)
#
#     # 获取目标深度
#     # print(detections)
#     for cls, pixel_coordinates in detections.items():
#         for i in range(len(pixel_coordinates)):
#             # print(pixel_coordinates[i])
#             x = pixel_coordinates[i][0]
#             y = pixel_coordinates[i][1]
#             depth_value = depth_image[y, x]
#             pixel_coordinates[i] = tuple([x, y, depth_value])
#             print(f"RGB图像上({x}, {y})点{cls}的深度值: {depth_value} mm")
#     print(detections)
#     return detections
#
#
# def detect_image_use_yolov8(image_timestamp: str) -> dict:
#     # 选择yolo模型
#     model = YOLO('models/yolov8n.pt')
#     # 读取待检测图像
#     image_path = os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'color_images/', 'color_' + image_timestamp + '.png')
#     image = cv2.imread(image_path)
#     # 执行目标检测
#     results = model(image)
#
#     # 初始化一个字典存储检测结果
#     detections = {}
#
#     # 解析检测结果
#     for result in results:
#         for box in result.boxes:
#             # 获取边界框坐标
#             x1, y1, x2, y2 = map(int, box.xyxy[0])
#
#             # 计算中心点坐标
#             center_x = (x1 + x2) // 2
#             center_y = (y1 + y2) // 2
#
#             # 获取检测类别名称
#             class_name = result.names[box.cls[0].item()]
#
#             # 将中心点坐标添加到字典
#             if class_name not in detections:
#                 detections[class_name] = []
#             detections[class_name].append((center_x, center_y))
#
#     # 绘制检测框及中心点
#     annotated_image = results[0].plot()
#     for class_name, centers in detections.items():
#         for center in centers:
#             center_x, center_y = center
#             cv2.circle(annotated_image, (center_x, center_y), 5, (0, 255, 0), -1)
#
#     # 保存检测结果图像
#     cv2.imwrite(os.path.join('E:\\WorkSpaces\\Python_WorkSpace\\AI\\Agent\\QwenAgent\\Kinect\\images', 'detected_images/', 'detected_' + image_timestamp + '.png'), annotated_image)
#
#     return detections

#
# if __name__ == '__main__':
#     get_kinect_images()
#     trans_pixel2camera({'person': [(722, 508, 336)]})
